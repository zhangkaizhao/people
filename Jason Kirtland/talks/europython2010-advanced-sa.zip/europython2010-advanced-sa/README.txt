This directory contains example code that accompanies the tutorial
presentation.  If you'd like to follow along during the presentation
you have a few options:

  1) Read the .py files in a text editor.  Each slide's worth of code
     is marked.
  2) Execute the .py file.  This will start up an enhanced interactive
     Python session ('python -i') that will the code slides one at a
     time.  This is a great way to explore the concepts and complete
     the exercises.  If readline is available, you also get tab completion
     and cool history features.  (press "up".)
  3) If the interactive mode doesn't appeal, you can still run the code
     by copy and pasting into an interpreter or modifying the .py itself.

The interactive mode has some extra commands specific to the slide
presentation.  They do not need to be typed with parens().

  next (or just press enter on a blank line)
    Run the next slide of code
  quick off
    Turn off 'enter == next' mode if it annoys you
  echo on|off
    Toggles the echo of SQL activity to the console.
    Echo defaults to on.
  goto #
    Skip forward to another slide.  If you hose your environment, just
    exit the shell and skip forward to where you left off to reset it.
