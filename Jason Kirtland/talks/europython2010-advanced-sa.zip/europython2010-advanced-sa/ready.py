#!/usr/bin/env python
import os, sys

NEED = '0.6.3'

prefix = '[*] '
write = lambda s: sys.stdout.write(prefix + s.rstrip() + '\n')
def bail(reason):
    write('Error: ' + reason)
    sys.exit(-1)

write('SQLAlchemy Tutorial - EuroPython - July 17th, 2010')
write('Checking prerequisites...')

if sys.version_info < (2, 5) or sys.version_info[0] == 3:
    bail('Python 2.x (2.5+) is required for this tutorial.')
else:
    write('Python version OK.')

if os.path.exists('lib/SQLAlchemy-%s' % NEED):
    write('Looks like %s is unpacked in this directory.' % NEED)
    base = os.path.abspath('lib/SQLAlchemy-%s/lib' % NEED)
    sys.path.insert(0, base)
elif os.path.exists('lib/SQLAlchemy-%s.zip' % NEED):
    write('Found an %s zip archive.' % NEED)
    base = os.path.abspath('lib/SQLAlchemy-%s.zip' % NEED)
    sys.path.insert(0, base + '/SQLAlchemy-%s/lib' % NEED)
else:
    write('No SQLAlchemy %s source distribution found in the lib directory.' %
          NEED)

try:
    import sqlalchemy
except ImportError:
    print(sys.path)
    bail('Could not find a SQLAlchemy %s library in the lib directory or '
         'on sys.path.' % NEED)
found = getattr(sqlalchemy, '__version__', '0.3.8') 
if found == 'svn':
    write('This tutorial requires version %s but you have an svn version. '
          "Proceding anyhow, you've been warned." % NEED)
elif found != NEED:
    bail('This tutorial is written for SQLAlchemy %s, found %s' % (
            NEED, found))
else:
    write('Found SQLAlchemy %s' % found)

try:
    sqlalchemy.create_engine('sqlite://')
except ImportError:
    if sys.version_info[:2] == (2, 4):
        bail('Could not find pysqlite.  SQLite support is required. Install '
             'pysqlite or run with Python 2.5')
    else:
        bail('This Python is missing sqlite3.  SQLite support is required, '
             'try installing pysqlite.')
else:
    write('SQLite loads OK')

try:
    import readline
except ImportError:
    write('Readline support not available.')
else:
    write('Right on, this Python supports readline.')

readme = open('README.txt')
if readme:
    write('Printing README.txt')
    sys.stdout.writelines(readme.readlines())
    readme.close()
else:
    write("README.txt missing.")

print("""
Running a two slide test presentation now.
Type 'next' when prompted!
""")

try:
    import sliderepl
except Exception, exc:
    bail('Failed to load slide harness.  If the issue can not be resolved, '
         'copy and paste code from the sample files into a Python prompt.')
else:
    write('Passing control to sliderepl')

class ReadyDeck(sliderepl.SADeck):
    def start(self):
        sliderepl.SADeck.start(self)

ReadyDeck.run()

### slide:: 1

message = "Hooray!"
print("This is the first slide.", message)
print("Code from slides executes in your environment.\n"
      "Try typing 'print message' and using tab completion if available.\n"
      "When you're done, go on to the next slide.")

### slide:: 2

[i * 2 for i in range(5)]

# That's it.  Enjoy the presentation!

### slide:: end
