import sliderepl
sliderepl.SADeck.run()

### slide:: 1

from sqlalchemy import create_engine, MetaData, Table, Column, \
     String, Integer

metadata = MetaData()

### slide:: 2

engine = create_engine('sqlite:///:memory:')
cx = engine.connect()
results = cx.execute('SELECT 1')

### slide:: 3

engine.name

### slide:: 4

engine.dialect.dbapi

### slide:: 5

engine.pool

### slide:: 6

engine.pool._creator()

### slide:: 7

engine.dialect.server_version_info

### slide:: 8

from sqlalchemy import exc

class LookLively(object):
    """Ensures that MySQL connections checked out of the pool are alive."""

    def checkout(self, dbapi_con, con_record, con_proxy):
        try:
            try:
                dbapi_con.ping(False)
            except TypeError:
                dbapi_con.ping()
        except dbapi_con.OperationalError, ex:
            if ex.args[0] in (2006, 2013, 2014, 2045, 2055):
                raise exc.DisconnectionError()
            else:
                raise

if engine.name == 'mysql':
    engine.pool.add_listener(LookLively())

### slide:: 9
import time

cx = engine.connect()
cx.info['connected_at'] = time.time()
cx.info

### slide:: 10

def updated_by(context):
    return context.connection.info.get('updated_by')

records = Table('records', metadata,
                Column('record_id', Integer, primary_key=True),
                Column('updated_by', Integer,
                       default=updated_by,
                       onupdate=updated_by),
                Column('data', String))

### slide:: 11

metadata.create_all(engine)

cx = engine.connect()
cx.info['updated_by'] = 123

cx.execute(records.insert(), data='inserted')
print cx.execute(records.select()).fetchall()

### slide:: 12

cx.info['updated_by'] = 456
cx.execute(records.update().where(records.c.data == 'inserted'),
           data='updated')

print cx.execute(records.select()).fetchall()

cx.close()

### slide:: 13

def cleanup(dbapi_con, con_record):
    con_record.info.pop('updated_by', None)

### slide:: 14

engine.pool.add_listener({'checkin': cleanup})

cx = engine.connect()
cx.info['updated_by'] = 789
cx.execute(records.insert(), data='new row')
cx.close()

cx = engine.connect()
print cx.info
cx.close()

### slide:: 15

import re
from sqlalchemy import interfaces
import sqlalchemy.sql.expression as expr


class RDBMSChangeWatcher(interfaces.ConnectionProxy):
    safe_re = re.compile(
        r'\s*(?:CREATE|DROP|PRAGMA|SET|BEGIN|COMMIT|ROLLBACK)\b',
        re.I)

    def __init__(self):
        self.dirty = set()
        self.reset_all = False

    def execute(self, conn, execute, clauseelement, *multiparams, **params):
        action = type(clauseelement)

        if action == expr.Select:
            pass
        elif action in (expr.Insert, expr.Update, expr.Delete):
            self.dirty.add(clauseelement.table)
        elif action in (str, unicode):
            # Executing custom sql.  Could parse it, instead just reseting
            # everything.
            if not self.safe_re.match(clauseelement):
                self.reset_all = True
        else:
            self.reset_all = True
        return execute(clauseelement, *multiparams, **params)

    # ...

    def cleanup(self, metadata, connection):
        if not (self.dirty or self.reset_all):
            return

        transaction = connection.begin()
        try:
            if self.reset_all:
                for table in reversed(metadata.sorted_tables):
                    connection.execute(table.delete())
            else:
                for table in reversed(metadata.sorted_tables):
                    if table in self.dirty:
                        connection.execute(table.delete())
            self.clear()
        finally:
            transaction.commit()

    def clear(self):
        self.dirty.clear()
        self.reset_all = False


### slide:: 16


watcher = RDBMSChangeWatcher()
engine = create_engine('sqlite:///', proxy=watcher)
records.create(engine)

print engine.execute(records.select()).fetchall()
print 'dirty', [t.name for t in watcher.dirty]

engine.execute(records.insert(), data='first row')
print 'inserted', engine.execute(records.select()).fetchall()
print 'dirty', [t.name for t in watcher.dirty]

watcher.cleanup(metadata, engine.connect())

print 'post-cleanup', engine.execute(records.select()).fetchall()

### slide:: end
