import sliderepl
import sys
sys.path.append('lib/pytz-2010h.zip/pytz-2010h')
sys.path.append('lib/pytz-2010h')
sliderepl.SADeck.run()

### slide:: 1
from sqlalchemy import create_engine, select, func
engine = create_engine('sqlite:///')

### slide:: 2

from sqlalchemy import MetaData, Table, Column, String, Integer

metadata = MetaData()

users = Table('users', metadata,
              Column('id', Integer, primary_key=True),
              Column('email', String))

### slide:: 3

users.info

### slide:: 4

users.c.id.info

### slide:: 5

from sqlalchemy import DateTime


LAST_UPDATED = Column('updated_at', DateTime, nullable=False)

table_1 = Table('table_1', metadata,
                Column('id', Integer, primary_key=True),
                LAST_UPDATED)

table_2 = Table('table_2', metadata,
                Column('id', Integer, primary_key=True),
                LAST_UPDATED)


### slide:: 6

def timestamped_table(*args, **kw):
    final_args = list(args) + [
        Column('updated_at', DateTime, nullable=False)
        ]
    return Table(*final_args, **kw)

### slide:: 7

table_2 = timestamped_table('table_2', metadata,
                            Column('id', Integer, primary_key=True))

[col.name for col in table_2.columns]

### slide:: 8

from sqlalchemy.types import TypeDecorator
from pytz import timezone


class Timezone(TypeDecorator):
    impl = String

    def process_bind_param(self, value, dialect):
        if isinstance(value, (basestring, type(None))):
            return value
        return value.zone

    def process_result_value(self, value, dialect):
        if value is None:
            return value
        try:
            return timezone(value)
        except NameError:
            return value

### slide:: 9

events = Table('events', metadata,
               Column('id', Integer, primary_key=True),
               Column('occurred_at', DateTime),
               Column('occurred_tz', Timezone))

### slide:: 10

from datetime import datetime

cx = engine.connect()

events.create(cx)
cx.execute(events.insert(), occured_at=datetime.now(),
           occurred_tz=timezone('America/Los_Angeles'))

print cx.execute(events.select()).fetchall()

### slide:: 11

class Fixture(object):
    """Associate a fixed data set with a Table."""

    def __init__(self, column_names, *rows):
        self.column_names = tuple(column_names)
        self.rows = list(rows)

    def _set_parent(self, table):
        """Implements sqlalchemy.schema.SchemaItem._set_parent."""
        table.append_ddl_listener('after-create', self.load_fixture_data)
        table.info['fixture'] = self

    def load_fixture_data(self, event, schema_item, connection):
        """Unconditionally load fixed data into a Table."""
        insert = schema_item.insert()
        data = (dict(zip(self.column_names, values))
                for values in self.rows)
        connection.execute(insert, *data)

### slide:: 12

locations = Table('location', metadata,
                  Column('x', Integer),
                  Column('y', Integer),
                  Fixture(('x', 'y'),
                          (10, 10),
                          (20, 20)),
                  )

cx = engine.connect()
locations.create(cx)
print cx.execute(locations.select()).fetchall()
print locations.info['fixture'].rows

### slide:: 13

from sqlalchemy.sql.expression import ColumnElement
from sqlalchemy.ext.compiler import compiles


class utcnow(ColumnElement):
    type = DateTime()


@compiles(utcnow, 'sqlite')
def compile_timestamp(element, compiler, **kw):
    return "datetime('now')"


@compiles(utcnow, 'postgresql')
def compile_timestamp(element, compiler, **kw):
    return "TIMESTAMP 'now' AT TIME ZONE 'utc'"

@compiles(utcnow)
def compile_timestamp(element, compiler, **kw):
    return "current_timestamp"


### slide:: 14

from sqlalchemy.dialects.postgresql import dialect as postgres
from sqlalchemy.dialects.sqlite import dialect as sqlite

print utcnow().compile(dialect=sqlite())
print utcnow().compile(dialect=postgres())
print utcnow()

### slide:: end
