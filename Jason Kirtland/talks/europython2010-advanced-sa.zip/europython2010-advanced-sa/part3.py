import sliderepl
sliderepl.SADeck.run()

### slide:: 1

from sqlalchemy import create_engine, MetaData, Table, Column, Integer, \
     String, ForeignKey
from sqlalchemy.orm import mapper, relation, create_session, sessionmaker, \
     scoped_session, clear_mappers
from sqlalchemy.ext.declarative import declarative_base

engine = create_engine('sqlite:///')
metadata = MetaData(engine)
Base = declarative_base(metadata=metadata)


def updated_by(context):
    return context.connection.info.get('updated_by')

users_table = Table('users', metadata,
                    Column('id', Integer, primary_key=True),
                    Column('email', String))

comments_table = Table('comments', metadata,
                       Column('id', Integer, primary_key=True),
                       Column('text', String),
                       Column('posted_by_id', Integer,
                              ForeignKey(users_table.c.id)))

records_table = Table('records', metadata,
                      Column('id', Integer, primary_key=True),
                      Column('updated_by', Integer,
                             default=updated_by,
                             onupdate=updated_by),
                      Column('data', String))

locations_table = Table('locations', metadata,
                        Column('x', Integer, primary_key=True),
                        Column('y', Integer, primary_key=True))


metadata.create_all()

### slide:: 2

class User(object):
    def __init__(self, email=None):
        self.email = email


class Comment(object):
    def __init__(self, text=None):
        self.text = text


class Record(object):
    def __init__(self, data=None):
        self.data = data


mapper(Comment, comments_table)

mapper(User, users_table, properties={
    'comments': relation(Comment, backref='posted_by'),
    })

mapper(Record, records_table)

session = create_session()
session.add(User('jek@discorporate.us'))
session.flush()
del session

### slide:: 3

Session = scoped_session(sessionmaker())
session = Session()

user = session.query(User).filter(User.email.startswith('jek')).one()

### slide:: 4

from sqlalchemy.orm.attributes import get_history

print get_history(user, 'email')

user.email = 'jek+spam@discorporate.us'
print get_history(user, 'email')

### slide:: 5

from sqlalchemy.orm.session import Session


class CustomSession(Session):

    def __init__(self, **kw):
        extensions = kw.get('extension', [])
        extensions.append(ContextualDefaultPopulator())
        kw['extension'] = extensions
        super(CustomSession, self).__init__(**kw)
        self.info = {}

### slide:: 6

from collections import defaultdict
from sqlalchemy.orm.interfaces import SessionExtension


class ContextualDefaultPopulator(SessionExtension):
    """Links Session-level info with low-level Connection info."""

    def __init__(self):
        self._connection_map = defaultdict(list)

    def after_begin(self, session, transaction, connection):
        self.register(session, connection)
        self._connection_map[id(session)].append(connection)

    def after_commit(self, session):
        for connection in self._connection_map[id(session)]:
            self.unregister(connection)
        del self._connection_map[id(session)]

    after_rollback = after_commit

    def register(self, session, connection):
        """Copy session.info data to connection.info."""
        if 'updated_by' in session.info:
            connection.info['updated_by'] = session.info['updated_by']

    def unregister(self, connection):
        """Remove data from connection.info"""
        if 'updated_by' in connection.info:
            del connection.info['updated_by']

### slide:: 7

session_factory = sessionmaker(class_=CustomSession)

session = session_factory()
session.info['updated_by'] = 456

record = Record('record 1')
session.add(record)

print 'updated_by', record.updated_by

session.commit()

print 'after commit: updated_by', record.updated_by

### slide:: 8

from sqlalchemy.orm.interfaces import MapperExtension


class Location(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y


class AutoAdd(MapperExtension):
    """Automatically add instances to *session*."""

    def init_instance(self, mapper, class_, oldinit, instance, args, kwargs):
        session.add(instance)

    def init_failed(self, mapper, class_, oldinit, instance, args, kwargs):
        session.expunge(instance)

mapper(Location, locations_table, extension=AutoAdd())

point = Location(1, 2)
assert point in session

### slide:: 9

from sqlalchemy.orm import Query

class UserQuery(Query):

    def with_email(self, email):
        return self.filter_by(email=email)


### slide:: 10

print UserQuery(User, session=session).with_email('jek@discorporate.us').one()

### slide:: 11

class DatabaseManager(object):
    """A Django-like database manager."""

    _query_cls = None
    _query_passthrough = ['filter', 'filter_by', 'all', 'one', 'get']
    _session_passthrough = ['add', 'add_all', 'commit', 'delete', 'flush']

    def __init__(self, session=None):
        self.model = None
        self.session = session

    @property
    def query(self):
        """A Query of managed model class."""
        if self._query_cls:
            return self._query_cls(self.model, session=self.session())
        return self.session.query(self.model)

    def bind(self, model, session):
        """Called to link the manager to the model and default session."""
        assert self.model is None
        self.model = model
        if self.session is None:
            self.session = session

    def __getattr__(self, attribute):
        if attribute in self._query_passthrough:
            return getattr(self.query, attribute)
        if attribute in self._session_passthrough:
            return getattr(self.session, attribute)
        raise AttributeError(attribute)

### slide:: 12

from sqlalchemy.orm import EXT_CONTINUE


class DatabaseManagerExtension(MapperExtension):
    """Applies and binds DatabaseManager instances to model classes."""

    def __init__(self, session, default_factory=DatabaseManager):
        self.session = session
        self.default_factory = default_factory

    def instrument_class(self, mapper, cls):
        factory = getattr(cls, '_manager_factory', self.default_factory)
        manager = factory()
        cls.objects = manager
        manager.bind(cls, self.session)
        return EXT_CONTINUE


### slide:: 13

# We'll rework User to have managers- clean up the shell environment first.
clear_mappers()
session = scoped_session(sessionmaker())


### slide:: 14

class UserManager(DatabaseManager):

    _query_cls = UserQuery
    _query_passthrough = DatabaseManager._query_passthrough + ['with_email']


class User(object):

    _manager_factory = UserManager

    def __init__(self, email=None):
        self.email = email

    def __repr__(self):
        return '<User %r>' % self.email

mapper(User, users_table, extension=[DatabaseManagerExtension(session)])

### slide:: 15

User.objects
User.objects.all()

user2 = User('sqlalchemy@googlegroups.com')
User.objects.add(user2)
User.objects.with_email('sqlalchemy@googlegroups.com').first()

### slide:: end
